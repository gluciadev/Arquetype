globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
      "static/chunks/node_modules_next_dist_compiled_166120c5._.js",
      "static/chunks/node_modules_next_dist_shared_lib_2c2ec201._.js",
      "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
      "static/chunks/node_modules_next_dist_5b402162._.js",
      "static/chunks/node_modules_next_app_72f3d36f.js",
      "static/chunks/[next]_entry_page-loader_ts_742e4b53._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_db4bb196._.js",
      "static/chunks/[root-of-the-server]__45f039c3._.js",
      "static/chunks/pages__app_2da965e7._.js",
      "static/chunks/turbopack-pages__app_63a81fd1._.js"
    ],
    "/_error": [
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
      "static/chunks/node_modules_next_dist_compiled_166120c5._.js",
      "static/chunks/node_modules_next_dist_shared_lib_b4122b32._.js",
      "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
      "static/chunks/node_modules_next_dist_0cccb603._.js",
      "static/chunks/node_modules_next_error_1cfbb379.js",
      "static/chunks/[next]_entry_page-loader_ts_43b523b5._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_db4bb196._.js",
      "static/chunks/[root-of-the-server]__092393de._.js",
      "static/chunks/pages__error_2da965e7._.js",
      "static/chunks/turbopack-pages__error_18aa0e75._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/node_modules_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_57d40746._.js",
    "static/chunks/node_modules_next_dist_compiled_react-dom_1e674e59._.js",
    "static/chunks/node_modules_next_dist_compiled_next-devtools_index_a9cb0712.js",
    "static/chunks/node_modules_next_dist_compiled_5150ccfd._.js",
    "static/chunks/node_modules_next_dist_client_cf1d9188._.js",
    "static/chunks/node_modules_next_dist_b0daae9a._.js",
    "static/chunks/node_modules_@swc_helpers_cjs_b3dc30d6._.js",
    "static/chunks/_a0ff3932._.js",
    "static/chunks/turbopack-_cdba956c._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];
module.exports = [
"[project]/messages/es.json (json)", (() => {{

throw new Error("An error occurred while generating the chunk item [project]/messages/es.json (json)\n\nCaused by:\n- Unable to make a module from invalid JSON: EOF while parsing a value at line 1 column 0\n\nDebug info:\n- An error occurred while generating the chunk item [project]/messages/es.json (json)\n- Execution of *EcmascriptChunkItemContent::module_factory failed\n- Execution of <JsonChunkItem as EcmascriptChunkItem>::content failed\n- Unable to make a module from invalid JSON: EOF while parsing a value at line 1 column 0\n    at .");

}}),
];
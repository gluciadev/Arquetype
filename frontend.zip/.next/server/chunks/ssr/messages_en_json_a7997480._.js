module.exports = [
"[project]/messages/en.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v(JSON.parse("{\"home\":{\"title\":\"Hello world\"},\"users\":{\"title\":\"Users\"}}"));}),
];
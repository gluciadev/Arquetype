import React from 'react'

export const MainContent = () => {
  return (
    <div>MainContent</div>
  )
}

'use client'

import React from 'react'
import { Header } from './components/Header/Header'
import { MainContent } from './components/MainContent/MainContent'
import { useFeatureFlags } from '@/services/growthbook/useFeatureFlags'
import { useGetUserById } from '@/services/api/users'

export const Users = () => {
    const { isEnableTestingFlag } = useFeatureFlags();
    const userData = useGetUserById({userId: "1"})
    console.log("USER DATA", userData.data)
  return (
    <div>
        <Header/>
        <MainContent/>
        {isEnableTestingFlag && "example flag working"}
    </div>
  )
}

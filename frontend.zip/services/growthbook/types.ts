export enum FeatureFlags {
  TESTING_FIRST_KEY_FLAG = "exampleFlag",
}
//https://iop-pro-growthbkwb-swdevelop-private-global.apps.aks01-pro.azure.ecommerce.inditex.grp/features  -- acceso a la lista de features
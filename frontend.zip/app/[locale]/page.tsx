
export default function Home() {
  return (
    <div>
     Hola mundo
    </div>
  );
}
